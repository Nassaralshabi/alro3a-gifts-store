# صور الموقع السابق — نسخة مضغوطة

تتضمن هذه الحزمة نسخة مضغوطة من 22 صورة أصلية جُمعت من الموقع السابق. حُوّلت الصور إلى WebP وخُفّض أكبر بُعد لها إلى 1200 بكسل دون قصّ المحتوى، لتبقى الحزمة مناسبة للمشاركة والتنزيل.

| المصدر الأصلي | الملف المضغوط |
|---|---|
| `01-social-and-boards/social-1_e277342a.jpg` | `01-social-and-boards/social-1_e277342a.webp` |
| `01-social-and-boards/social-2_de273aa2.jpg` | `01-social-and-boards/social-2_de273aa2.webp` |
| `01-social-and-boards/social-3_0108449b.jpg` | `01-social-and-boards/social-3_0108449b.webp` |
| `02-paper-bags/alrawaa-bag-abaya_92e84937.png` | `02-paper-bags/alrawaa-bag-abaya_92e84937.webp` |
| `02-paper-bags/alrawaa-bag-landscape-19x26_f1276432.png` | `02-paper-bags/alrawaa-bag-landscape-19x26_f1276432.webp` |
| `02-paper-bags/alrawaa-bag-landscape-22x32_776b9da1.png` | `02-paper-bags/alrawaa-bag-landscape-22x32_776b9da1.webp` |
| `02-paper-bags/alrawaa-bag-landscape-22x33_aedaa2fb.png` | `02-paper-bags/alrawaa-bag-landscape-22x33_aedaa2fb.webp` |
| `02-paper-bags/alrawaa-bag-landscape-42x22_12f54b8a.png` | `02-paper-bags/alrawaa-bag-landscape-42x22_12f54b8a.webp` |
| `02-paper-bags/alrawaa-bag-portrait-30x20_8e7bc527.png` | `02-paper-bags/alrawaa-bag-portrait-30x20_8e7bc527.webp` |
| `02-paper-bags/alrawaa-bag-portrait-40x28_9293ed87.png` | `02-paper-bags/alrawaa-bag-portrait-40x28_9293ed87.webp` |
| `02-paper-bags/alrawaa-bag-portrait-small_1e44c489.png` | `02-paper-bags/alrawaa-bag-portrait-small_1e44c489.webp` |
| `02-paper-bags/alrawaa-bag-top-flap_de82745e.png` | `02-paper-bags/alrawaa-bag-top-flap_de82745e.webp` |
| `03-gift-boxes/alrawaa-chocolate-box_986639ac.png` | `03-gift-boxes/alrawaa-chocolate-box_986639ac.webp` |
| `03-gift-boxes/alrawaa-cup-holder_01ccf8c3.png` | `03-gift-boxes/alrawaa-cup-holder_01ccf8c3.webp` |
| `03-gift-boxes/alrawaa-cup-sweets-box_4754efdf.png` | `03-gift-boxes/alrawaa-cup-sweets-box_4754efdf.webp` |
| `03-gift-boxes/alrawaa-favors-box_1fadd669.png` | `03-gift-boxes/alrawaa-favors-box_1fadd669.webp` |
| `03-gift-boxes/alrawaa-sliding-box-reference_286aefc0.png` | `03-gift-boxes/alrawaa-sliding-box-reference_286aefc0.webp` |
| `03-gift-boxes/alrawaa-triangle-box_f822a955.png` | `03-gift-boxes/alrawaa-triangle-box_f822a955.webp` |
| `04-print-items/paper-cup-8oz-source-optimized_c46cb2e7.webp` | `04-print-items/paper-cup-8oz-source-optimized_c46cb2e7.webp` |
| `04-print-items/round-sticker-7cm-source_0b26681e.jpg` | `04-print-items/round-sticker-7cm-source_0b26681e.webp` |
| `04-print-items/thank-you-card-10x7-source_4db9df15.jpg` | `04-print-items/thank-you-card-10x7-source_4db9df15.webp` |
| `05-homepage/home-hero-original_ba87519b.jpg` | `05-homepage/home-hero-original_ba87519b.webp` |
